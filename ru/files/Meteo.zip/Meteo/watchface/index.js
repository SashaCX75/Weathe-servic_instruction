﻿
	/********************************
	*								*
	*			Meteo	v0.4		*
	*		2024 © leXxiR [4pda]	*
	*								*
	*********************************/
	   
    try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;


		const wfv = 'v0.1'			// версия циферблата (для сброса настроек)
        
        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
		const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2
		const koeff = DEVICE_WIDTH / 466;		// коэффициент масштабирования

		let isAOD = hmSetting.getScreenType() == hmSetting.screen_type.AOD;

		let lang = hmSetting.getLanguage() == 4 ? 0 : 1
		//let mileageUnit = hmSetting.getMileageUnit();	// 0 	metric (СИ)			1 	imperial
		//let timeFormat = hmSetting.getTimeFormat();		// 0 	12					1	24

		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
		
		const step = hmSensor.createSensor(hmSensor.id.STEP);
		const heart = hmSensor.createSensor(hmSensor.id.HEART);
		const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);

		const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
		const stand = hmSensor.createSensor(hmSensor.id.STAND)
		const pai = hmSensor.createSensor(hmSensor.id.PAI);
		const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
		const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
		const stress = hmSensor.createSensor(hmSensor.id.STRESS);

		//const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		//let weather_icons = Array.from(Array(29), (v, k) => `w_${k}.png`)

		let battText, battScale
		let dateText, dayNameText = [], dayTemp = [], dayWeatherIcon = []
		const daysNum = 5
		let hourText, minText
		
		let curTempText, curWeatherIcon, curCityName, curHumText, curWindText, curWindPointer, updateTimeText

		const speedUnit = [	
							[' м/с', ' m/s'],		//0
						]								
							
		const pressUnit = [	
							[' мм', ' mmHg'],		//0
							[' ГПа', ' hPa'], 		//1
						]
							
		const distUnit = [	
							[' м', ' m'],		//0
							[' км', ' km'],		//1
						]
							
		const windDirectionStr = [
							['С', 'N'],								// 0
							['СВ', 'NE'],							// 1
							['В', 'E'],								// 2
							['ЮВ', 'SE'],							// 3
							['Ю', 'S'],								// 4
							['ЮЗ', 'SW'],							// 5
							['З', 'W'],								// 6
							['СЗ', 'NW'],							// 7
						];



		let actValueText, actScale
		let actIndex = 0
		let actIcon
		
		const activities = [
							['ШАГИ', 'STEPS'], 								// 0
							['РАССТОЯНИЕ', 'DISTANCE'],  					// 1
							['ПУЛЬС', 'HEART'],		  						// 2
							['КАЛОРИИ', 'CALORIES'],  						// 3
							['КАРДИО', 'FAT BURNING'], 						// 4
							['РАЗМИНКА', 'STAND'],  						// 5
							['PAI', 'PAI'], 		 						// 6
							['КИСЛОРОД', 'OXYGEN'], 						// 7
						]
		
		const actNum = activities.length;

		let copyright = ''

		let longPress_Timer = null;
		const longPressDelay = 1000;
		let getLongTap = false
		
		let activity_btn = ''

		let degreeSum = 0
		const crownSensitivity = 70		// уровень чувствительности колесика

	
		// функция функция мастшабирования значений в зависимости от размера экрана
		function sc(v) {
			return v * koeff
		}

        function getLangIndex() {
			lang = hmSetting.getLanguage() == 4 ? 0 : 1
			//lang = 0
        }


		// класс текст с обводкой
		class TextWithOutline {      
		  constructor(props) {
			this._x = props.x || 0;
			this._y = props.y || 0;
			this._widget = [];
			this._color = (props.color == null) ? 0xffffff : props.color;
			this._color_outline = (props.color_outline == null) ? 0x000000 : props.color_outline;
			this._offset = props.offset || 2;
			this._group = props.group || hmUI;

			for (let i = 0; i < 5; i++) {
				this._widget[i] = this._group.createWidget(hmUI.widget.TEXT, {
					x: this._x,
					y: this._y,
					w: props.w || 100,
					h: props.h || 40,
					text_size: props.text_size || 30,
					char_space: props.char_space || 0,
					line_space: props.line_space || 0,
					text: props.text,
					color: i > 3 ? this._color : this._color_outline,
					align_h: props.align_h || hmUI.align.CENTER_H,
					align_v: props.align_v || hmUI.align.CENTER_V,
					text_style: props.text_style || hmUI.text_style.NONE,
				});

				if (props.font){
					this._widget[i].setProperty(hmUI.prop.MORE, {
						font: props.font
					});
				}
			}

			this._widget[0].setProperty(hmUI.prop.MORE, {
				x: this._x - this._offset,
				y: this._y + this._offset
			});
			this._widget[1].setProperty(hmUI.prop.MORE, {
				x: this._x + this._offset,
				y: this._y - this._offset
			});
			this._widget[2].setProperty(hmUI.prop.MORE, {
				x: this._x - this._offset,
				y: this._y - this._offset
			});
			this._widget[3].setProperty(hmUI.prop.MORE, {
				x: this._x + this._offset,
				y: this._y + this._offset
			});
		  }
		
		  hide() {
			this._widget.forEach(item => {
			  item.setProperty(hmUI.prop.VISIBLE, false);
			});
		  }

		  show() {
			this._widget.forEach(item => {
			  item.setProperty(hmUI.prop.VISIBLE, true);
			});
		  }

		  set visible(v) {
			if (v) this.show()
			else  this.hide();
		  }
		  
		  set x(v) {
			this._x = v;
			this._widget[4].setProperty(hmUI.prop.MORE, {x: this._x});
			this._widget[0].setProperty(hmUI.prop.MORE, {x: this._x - this._offset});
			this._widget[1].setProperty(hmUI.prop.MORE, {x: this._x + this._offset});
			this._widget[2].setProperty(hmUI.prop.MORE, {x: this._x - this._offset});
			this._widget[3].setProperty(hmUI.prop.MORE, {x: this._x + this._offset});
		  }

		  set y(v) {
			this._y = v;
			this._widget[4].setProperty(hmUI.prop.MORE, {y: this._y});
			this._widget[0].setProperty(hmUI.prop.MORE, {y: this._y + this._offset});
			this._widget[1].setProperty(hmUI.prop.MORE, {y: this._y - this._offset});
			this._widget[2].setProperty(hmUI.prop.MORE, {y: this._y - this._offset});
			this._widget[3].setProperty(hmUI.prop.MORE, {y: this._y + this._offset});
		  }

		  set text(txt) {
			this._widget.forEach(item => {
			  item.setProperty(hmUI.prop.TEXT, txt);
			});
		  }
		  
		  set color(v) {
			this._color = v;
			this._widget[4].setProperty(hmUI.prop.MORE, {color: this._color});
		  }

		  set color_outline(v) {
			this._color_outline = v;
			for (let i = 0; i < 4; i++) {
				this._widget[i].setProperty(hmUI.prop.MORE, {color: this._color_outline});
			}
		  }		  
		}
	
		// класс текст с тенью
		class TextWithShadow {      
		  constructor(props) {
			this._x = props.x || 0;
			this._y = props.y || 0;
			this._offset = props.offset || 2;
			this._group = props.group || hmUI;
			
			this._shadow = this._group.createWidget(hmUI.widget.TEXT, {
				x: this._x + this._offset,
				y: this._y + this._offset,
				w: props.w || 100,
				h: props.h || 100,
				text_size: props.text_size || 30,
				char_space: props.char_space || 0,
				line_space: props.line_space || 0,
				text: props.text,
				color: (props.color_shadow == null) ? 0x000000 : props.color_shadow,
				align_h: props.align_h || hmUI.align.CENTER_H,
				align_v: props.align_v || hmUI.align.CENTER_V,
				text_style: props.text_style || hmUI.text_style.NONE,
			});

			this._widget = this._group.createWidget(hmUI.widget.TEXT, {
				x: this._x,
				y: this._y,
				w: props.w || 100,
				h: props.h || 40,
				text_size: props.text_size || 30,
				char_space: props.char_space || 0,
				line_space: props.line_space || 0,
				text: props.text,
				color: (props.color == null) ? 0xffffff : props.color,
				align_h: props.align_h || hmUI.align.CENTER_H,
				align_v: props.align_v || hmUI.align.CENTER_V,
				text_style: props.text_style || hmUI.text_style.NONE,
			});

			if (props.font){
				this._widget.setProperty(hmUI.prop.MORE, {
					font: props.font
				});
				this._shadow.setProperty(hmUI.prop.MORE, {
					font: props.font
				});
			}
		  }
		
		  hide() {
			this._widget.setProperty(hmUI.prop.VISIBLE, false);
			this._shadow.setProperty(hmUI.prop.VISIBLE, false);
		  }

		  show() {
			this._widget.setProperty(hmUI.prop.VISIBLE, true);
			this._shadow.setProperty(hmUI.prop.VISIBLE, true);
		  }

		  set visible(v) {
			if (v) this.show()
			else  this.hide();
		  }
		  
		  set x(v) {
			this._x = v;
			this._widget.setProperty(hmUI.prop.MORE, {x: this._x});
			this._shadow.setProperty(hmUI.prop.MORE, {x: this._x + this._offset});
		  }

		  set y(v) {
			this._y = v;
			this._widget.setProperty(hmUI.prop.MORE, {y: this._y});
			this._shadow.setProperty(hmUI.prop.MORE, {y: this._y + this._offset});
		  }

		  set text(txt) {
			this._widget.setProperty(hmUI.prop.TEXT, txt);
			this._shadow.setProperty(hmUI.prop.TEXT, txt);
		  }

		  set color(v) {
			this._widget.setProperty(hmUI.prop.MORE, {color: v});
		  }
		}	



//------------- батарея ------------------
		function updateBattery() {
			let val = battery.current;
			//battText.setProperty(hmUI.prop.TEXT, val + '%');
			battText.text = val + '%'; 
            battScale.setProperty(hmUI.prop.MORE, {
			  x: sc(190),
			  y: sc(17),
			  w: (DEVICE_WIDTH - 2 * sc(190)) * val / 100,
			  h: 10,
              color: 0xdedede,
			  radius: 3,
            });
		}


//------------- дата и день недели ------------------
		let lastDate = {date: 0, day: 0, month: 0}

		const day_names = [	
								["ПН", "Mon"],
								["ВТ", "Tue"],
								["СР", "Wed"],
								["ЧТ", "Thu"],
								["ПТ", "Fri"],
								["СБ", "Sat"],
								["ВС", "Sun"]
							]
		
		function updateDate() {
			if (curTime.day != lastDate.date){
				lastDate.date = curTime.day;
				//dateText.setProperty(hmUI.prop.TEXT, curTime.day.toString().padStart(2, "0"));
				dateText.setProperty(hmUI.prop.TEXT, curTime.day.toString());
			}

			if (curTime.week != lastDate.day){
				lastDate.day = curTime.week;
				let curDayNum = curTime.week - 1;
				for(let i = 0; i < daysNum; i++) {
					dayNameText[i].setProperty(hmUI.prop.MORE, {
					  text: day_names[curDayNum][lang],
					  font: 'fonts/DirectoBold.ttf',
					  color: curDayNum > 4 ? 0xdb0000: 0xdedede,
					});
					curDayNum = (curDayNum + 1) % 7;
				}				
				//dayNameText.text = getCurrentDayName();
			}
		}

		function getCurrentDayName() {
			return  day_names[curTime.week - 1][lang];
        }

		function getCurrentMonthName() {
			const month_names = [	
									["ЯНВ", "JAN"],
									["ФЕВ", "FEB"],
									["МАР", "MAR"],
									["АПР", "APR"],
									["МАЙ", "MAY"],
									["ИЮН", "JUN"],
									["ИЮЛ", "JUL"],
									["АВГ", "AUG"],
									["СЕН", "SEP"],
									["ОКТ", "OCT"],
									["НОЯ", "NOV"],
									["ДЕК", "DEC"],
								];
							
			return  month_names[curTime.month - 1][lang];
        }

		function getMonthName(index) {
			const month_names = [	
									["января", "Jan"],
									["февраля", "Feb"],
									["марта", "Mar"],
									["апреля", "Apr"],
									["мая", "May"],
									["июня", "Jun"],
									["июля", "Jul"],
									["августа", "Aug"],
									["сентября", "Sep"],
									["октября", "Oct"],
									["ноября", "Nov"],
									["декабря", "Dec"],
								];
							
			return  month_names[index][lang];
        }


//------------- время ------------------
		let lastTime = {hour: 0, min: 0}

        function updateTime() {
			let curHour = curTime.hour;
			let curMinute = curTime.minute;
			if (curHour != lastTime.hour){
				lastTime.hour = curHour;
				curHour = curHour.toString().padStart(2, "0");
				//hourText.setProperty(hmUI.prop.TEXT, curHour);
				hourText.text = curHour; 
			}
			if (curMinute != lastTime.min){
				lastTime.min = curMinute;
				curMinute = curMinute.toString().padStart(2, "0");
				//minText.setProperty(hmUI.prop.TEXT, curMinute);
				minText.text = curMinute;
			}
        }


        function updateTimeAOD() {
			hourText.text = curTime.hour.toString().padStart(2, "0");
			minText.text = curTime.minute.toString().padStart(2, "0");
        }
		
//------------- обновить все данные ------------------
		function updateAllInfo() {
			updateTime();
			updateBattery();
			updateDate();
			updateActivity(actIndex);
		}



//------------- форматированное время ------------------
		function getFormatTime(h, m) {
			let fH = h;
			let ampm = 'am';
			if (h == 0) fH = 12;
			else if (h >12) {
				fH = h - 12;
				ampm = 'pm';
			}
			
			return `${fH}:${m.toString().padStart(2, "0")}${ampm}`
		}


		function randomInt(...args) {
			let min = 0;
			let max = args[0];
			if (args.length > 1) {
				min = args[0];
				max = args[1];
			}
			let rand = min + Math.random() * (max + 1 - min);
			return Math.floor(rand);
		}


//------------- активности ------------------
		function getActivityValue(index){
			let value = 0;

			switch(index) {
			   case 0:
					value = step.current.toString();
				break;
			   case 1:
					mileageUnit = hmSetting.getMileageUnit();
					if (mileageUnit == 1){
						const distUnit = ['ми', 'mi']
						let curDist = (distance.current / 1609.34).toFixed(2);
						value = curDist.toString() + distUnit[lang];
					} else {
						const distUnit = [['м', 'км'], ['m', 'km']]
						let ind = 1;
						let curDist = distance.current;
						if (curDist < 1000) {
							ind = 0;
						} else {
							curDist = (curDist / 1000).toFixed(2);
						}
						value = curDist.toString() + distUnit[lang][ind];
					}
				break;
			   case 2:
					value = heart.last;	//getLast();
					if (value) value = value.toString()
					else  value = '--';
				break;
			   case 3:
					value = calorie.current.toString();
				break;
			   case 4:
					value = fatburn.current.toString();
					if (value < 100 && fatburn.target < 100) value = value.toString() + '/' + fatburn.target.toString();
					else value = value.toString();
				break;
			   case 5:
					value = stand.current.toString() + '/' + stand.target.toString();
				break;
			   case 6:
					value = pai.totalpai.toString();
				break;
			   case 7:
					value = spo2.current;		// getCurrent().value
					if (value) value = value.toString() + '%';
					else  value = '--';
				break;
			   default:
					value = '--';
				break;
			}

			return value
		}

		function getActivityProgress(index){
			let value = 0;

			switch(index) {
			   case 0:
			   case 1:
					//value = step.getCurrent() / step.getTarget();
					value = step.current / step.target;
				break;
			   case 2:
					//let userAge = getProfile().age;
					let userAge = hmSetting.getUserData().age;
					if (!userAge) userAge = 40;
					const maxBPM = 220 - userAge - 60; // 220 — ваш возраст - 60 (покой) 
					//value = heart.getLast() - 60;	// сдвигаем шкалу: покой (60) - будет 0
					value = heart.last - 60;		// сдвигаем шкалу: покой (60) - будет 0	
					if (value < 0 ) value = 0;
					value = value / maxBPM;
				break;
			   case 3:
					//value = calorie.getCurrent() / calorie.getTarget();
					value = calorie.current / calorie.target;
				break;
			   case 4:
					//value = fatburn.getCurrent() / fatburn.getTarget();
					value = fatburn.current / fatburn.target;
				break;
			   case 5:
					//value = stand.getCurrent() / stand.getTarget();
					value = stand.current / stand.target;
				break;
			   case 6:
					//value = pai.getTotal() / 100;
					value = pai.totalpai / 100;
				break;
			   case 7:
					//value = spo2.getCurrent().value / 100;
					value = spo2.current / 100;
				break;
			   default:
					value = 0;
				break;
			}

			if (value > 1) value = 1;				
			return value				// возвращаем значение от 0 до 1
		}


		function updateActivity(index){
			//actValueText.setProperty(hmUI.prop.TEXT, getActivityValue(index));
			actValueText.text = getActivityValue(index); 
			//actText.setProperty(hmUI.prop.TEXT, activities[index][lang]);
			actIcon.setProperty(hmUI.prop.SRC, `ico_${index}.png`);
            actScale.setProperty(hmUI.prop.MORE, {
			  x: sc(160),
			  y: DEVICE_HEIGHT - 30,
			  w: (DEVICE_WIDTH - 2 * sc(160)) * getActivityProgress(index),
			  h: 10,
              color: 0xdedede,
			  radius: 3,
            });
		}


		function toggleActivity(step = 1) {							// переключаем активности по кругу
			actIndex += step;
			actIndex = actIndex < 0 ? actNum + actIndex : actIndex % actNum;
			updateActivity(actIndex);
			vibro();
        }


		function showActivityScreen() {
			vibro();
			let url = 'activityAppScreen';
			
			switch(actIndex) {
			   case 2:
					url = 'heart_app_Screen';
				break;
			   case 3, 6:
					url = 'PAI_app_Screen';
				break;
			   case 7:
					url = 'spo_HomeScreen';
				break;
			   default:
					url = 'activityAppScreen';
				break;
			}
			
			hmApp.startApp({ url: url, native: true });
			//launchApp({ url: url, native: true });
		}

//------------- вибро ------------------
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
		
		function vibro(scene = 25) {
			let stopDelay = 50;
			vibrate.stop();
			vibrate.scene = scene;
			if(scene < 23 || scene > 25) stopDelay = 1200;
			vibrate.start();
			stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
        }		

		function stopVibro(){
			vibrate.stop();
			timer.stopTimer(stopVibro_Timer);
		}



//------------- коронка ------------------
		function onDigitalCrown() {
			try {
				setTimeout(() => {
					hmApp.registerSpinEvent(function (key, degree) {
						degreeSum += degree;
						if (Math.abs(degreeSum) > crownSensitivity){
							let step = degreeSum < 0 ? -1 : 1;
							degreeSum = 0;
							/*
							if(userListScreen){
								if (Math.abs(degree) > 10) step *= 3;
								step *= listRowH;
								moveUserList(step);
							} else if(menuClosed) */toggleActivity(step);
						}
					})
				}, 250);
			} catch (e) {
				console.log('SpinEvent Error: ', e);
			}
		}

		function offDigitalCrown() {
			try {
				hmApp.unregisterSpinEvent();
			} catch (e) {
				console.log('SpinEvent Error: ', e);
			}
		}


		function getPressure(val, unit = 0){
			if (!val) return '--';
			if (!unit) val *= 0.750064;
			return Math.round(val).toString();
		}
		
		// температура со знаком
		function tempWithSign(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки

			val = Math.round(val);
			if (val > 0) val = '+' + val;
			val += '°';
			
			return val
		}  
				  
				  
		function getWindDescription(angle){
			let index = 0;
			if (angle >= 337.5 && angle < 22.5 ) index = 0;
			else if (angle >= 22.5 && angle < 67.5 ) index = 1;
			else if (angle >= 67.5 && angle < 112.5 ) index = 2;
			else if (angle >= 112.5 && angle < 157.5 ) index = 3;
			else if (angle >= 157.5 && angle < 202.5 ) index = 4;
			else if (angle >= 202.5 && angle < 247.5 ) index = 5;
			else if (angle >= 247.5 && angle < 292.5 ) index = 6;
			else if (angle >= 292.5 && angle < 337.5 ) index = 7;
			
			return windDirectionStr[index][lang];
		}

// чтение погодных данных из файла
		const mini_app_id = 1065824;
		const file_name_weather = "weather.json";
		const file_name_forecast = "forecast.json";

		function arrayBufferToCyrillic(buffer) {
		  let result = '';
		  const bytes = new Uint8Array(buffer);

		  let i = 0;
		  while (i < bytes.length) {
			let byte1 = bytes[i++];
			
			// Обработка 1-байтовых символов (ASCII)
			if (byte1 < 0x80) {
			  result += String.fromCharCode(byte1);
			}
			// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
			else if (byte1 >= 0xC0 && byte1 < 0xE0) {
			  let byte2 = bytes[i++];
			  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
			  result += String.fromCharCode(charCode);
			}
			// Обработка 3-байтовых символов (например, для UTF-8)
			else if (byte1 >= 0xE0 && byte1 < 0xF0) {
			  let byte2 = bytes[i++];
			  let byte3 = bytes[i++];
			  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
			  result += String.fromCharCode(charCode);
			}
		  }

		  return result;
		}

		function read_weather_file(file_name) {
		  let str_result = "";
		  try {

			const [fs_stat, err] = hmFS.stat(file_name, {
			  appid: mini_app_id,
			});
			if (err == 0) {
			  //console.log("--->size_alt:", fs_stat.size);

			  const fh = hmFS.open(file_name, hmFS.O_RDONLY, {
				appid: mini_app_id,
			  });

			  const len = fs_stat.size;
			  let array_buffer = new ArrayBuffer(len);
			  hmFS.read(fh, array_buffer, 0, len);
			  hmFS.close(fh);
			  str_result = arrayBufferToCyrillic(array_buffer);
			  //console.log(`array_buffer = ${array_buffer}`);
			  //console.log(`str_result = ${str_result}`);
			  return str_result;
			} else {
			  console.log("err:", err);
			}
		  } catch (error) {
			console.log("error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
		  return "";
		}

	// время последнего изменеия файла
		function getFileModTime(file_name) {
		  try {
			const [fs_stat, err] = hmFS.stat(file_name, {
			  appid: mini_app_id,
			});
			
			if (err == 0) {
			  //console.log("--->file time: ", fs_stat.mtime);
			  //hmUI.showToast({text: file_name + " time: " + fs_stat.mtime});
			  return fs_stat.mtime
			} else {
			  console.log("err:", err);
			}
		  } catch (error) {
			console.log("error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
			return null
		}

	
		
	// обновление погоды
		function updateWeather(data) {
		  console.log(`updateWeather()`);
	  
		  curCityName.setProperty(hmUI.prop.TEXT, data.cityName);
		  curTempText.setProperty(hmUI.prop.TEXT, data.temperature);
		  curHumText.setProperty(hmUI.prop.TEXT, data.humidity);
		  curWindText.setProperty(hmUI.prop.TEXT, data.windSpeed + speedUnit[0][lang]);
		  // textPressure.setProperty(hmUI.prop.TEXT, data.pressure);
		  updateTimeText.setProperty(hmUI.prop.TEXT, data.weatherTime);
		  curWeatherIcon.setProperty(hmUI.prop.SRC,  `w_${data.weatherIcon}.png`);
		  curWindPointer.setProperty(hmUI.prop.ANGLE, data.windDirection);
		  isDayIcons = true;
		}


// разница между датами в днях
		function getDaysBetweenDates(d0, d1) {
		  let diff = new Date(+d1).setHours(12) - new Date(+d0).setHours(12);	// устанавливаем время в каждой дате на 12
		  return Math.round(diff / 8.64e7);		// msPerDay = 8.64e7;
		}


	// обновление прогноза погоды по дням
		function updateForecast(data) {
			console.log(`updateForecast()`);

			let dayOffset = 0; 	// смещение дней для начала прогноза по дням
								// если прогноз был обновлен во ВТ, а сегодня СР, то dayOffset = 1
								// соотвественно для чтения данных будем использовать объект forecastJson.forecast[i + dayOffset]

			if (isFinite(data.weatherTime)) {
				dayOffset = getDaysBetweenDates(data.weatherTime, Date.now());
			}

			for(let i = 0; i < daysNum; i++) {
			  const ind = i + dayOffset;
			  dayTemp[i].high.setProperty(hmUI.prop.TEXT, data.forecast[ind].temperatureMax);
			  dayTemp[i].low.setProperty(hmUI.prop.TEXT, data.forecast[ind].temperatureMin);
			  if (i) dayWeatherIcon[i].setProperty(hmUI.prop.SRC, `w_${data.forecast[ind].weatherIcon}.png`);
			}
		}



		let weatherData, forecastData
		let  lastModTime = {
			weather: 0,
			forecast: 0,
		}

		function updateWeatherData() {
			if (lastModTime.weather != getFileModTime(file_name_weather)){
				weatherData = getWeatherData(file_name_weather);
				updateWeather(weatherData);
			}

			if (lastModTime.forecast != getFileModTime(file_name_forecast)){
				forecastData = getForecastData(file_name_forecast);
				updateForecast(forecastData);
			}			
		}




	//	авто переключение иконок погоды на ночные
		const nightIcons = [1, 2]
		let isDayIcons = true;

		function isDayNow() {
			let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
			let weatherDataZepp = weather.getForecastWeather();
			const sunriseMins_def = 8 * 60;			// время восхода
			const sunsetMins_def = 20 * 60;			// и заката по умолчанию

			let sunData = weatherDataZepp.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			let curMins = curTime.hour * 60 + curTime.minute;
			//let curMins = curTime.getHours() * 60 + curTime.getMinutes();
			let nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

			return nowIsDay
		}


		function toggleWeatherIcons() {
			if(nightIcons.includes(weatherData.weatherIcon)){
				const nowIsDay = isDayNow();

				if(nowIsDay){
					if(!isDayIcons){
						curWeatherIcon.setProperty(hmUI.prop.SRC,  `w_${weatherData.weatherIcon}.png`);
						isDayIcons = true;
					}
				} else {
					if(isDayIcons){
						curWeatherIcon.setProperty(hmUI.prop.SRC,  `w_${weatherData.weatherIcon}n.png`);
						isDayIcons = false;
					}
				}
			}
		}


//------------------------------------------------------



		function getWeatherData(fileName) {
		  console.log(`getWeatherData()`);

			let weather_str = read_weather_file(fileName);
			console.log(`weather_json = ${weather_str}`);
			let weatherJson = JSON.parse(weather_str);

			lastModTime.weather = getFileModTime(fileName);

			let data = {
				weatherIcon: 0,
				weatherDescription:  lang == 0 ? 'Нет данных' : 'No data',
				temperature: '--',
				temperatureFeels: '--',
				temperatureMax: '--',
				temperatureMin: '--',
				humidity: '--',
				pressure: '--',
				windSpeed: '--',
				windDirection: 0,
				windGusts: null,
				chanceOfRain : '--',
				cloudiness: '--',
				visibility: '--',
				cityName: '--',
				sunriseTime: '--',
				sunsetTime: '--',
				dayDuration: '--',
				weatherTime: '--:--',
			}

	  
			if (weatherJson != undefined && weatherJson != null) {
				if (weatherJson.city != undefined && weatherJson.city != null && weatherJson.city.length) {
				  data.cityName = weatherJson.city;
				  data.cityName = data.cityName.replace(data.cityName[0], data.cityName[0].toUpperCase());
				}
				
				if (weatherJson.weatherDescriptionExtended != undefined && weatherJson.weatherDescriptionExtended != null && weatherJson.weatherDescriptionExtended.length) {
				  data.weatherDescription = weatherJson.weatherDescriptionExtended;
				  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
				}

				if (isFinite(weatherJson.weatherIcon)) {
				  data.weatherIcon = parseInt(weatherJson.weatherIcon);
				}

				if (isFinite(weatherJson.temperature)) {
				  data.temperature = tempWithSign(weatherJson.temperature);

				  if (isFinite(weatherJson.temperatureFeels)){
					data.temperatureFeels = tempWithSign(weatherJson.temperatureFeels);
				  }
				  
				  if (isFinite(weatherJson.temperatureMax)){
					data.temperatureMax = tempWithSign(weatherJson.temperatureMax);
				  }
				  
				  if (isFinite(weatherJson.temperatureMin)){
					data.temperatureMin = tempWithSign(weatherJson.temperatureMin);
				  }
				}

				if (isFinite(weatherJson.humidity)) {
				  data.humidity = weatherJson.humidity + '%';
				}

				if (isFinite(weatherJson.chanceOfRain)) {
				  data.chanceOfRain = weatherJson.chanceOfRain + '%';
				}

				if (isFinite(weatherJson.windSpeed)) {
				  data.windSpeed = parseFloat(weatherJson.windSpeed);
				  data.windSpeed > 10 ? data.windSpeed = Math.round(data.windSpeed) : data.windSpeed = data.windSpeed.toFixed(1);
				}
				
				if (isFinite(weatherJson.windGusts)) {
				  data.windGusts = parseFloat(weatherJson.windGusts);
				  data.windGusts > 10 ? data.windGusts = Math.round(data.windGusts) : data.windGusts = data.windGusts.toFixed(1);
				}
				
				if (isFinite(weatherJson.windDirection)) {
				  data.windDirection = parseFloat(weatherJson.windDirection);
				}

				if (isFinite(weatherJson.pressure)) {
				  data.pressure = parseInt(weatherJson.pressure);
				  //pressureTrend
				}

				if (isFinite(weatherJson.visibility)) {
				  data.visibility = parseInt(weatherJson.visibility);
				  let unitIndex = 0;
				  if (data.visibility > 1000) {
				  	data.visibility = parseInt(data.visibility / 1000);
				  	unitIndex = 1;
				  	}
				  data.visibility += distUnit[unitIndex][lang];
				}

				if (isFinite(weatherJson.cloudiness)) {
				  data.cloudiness = parseInt(weatherJson.cloudiness);
				}

				if (isFinite(weatherJson.sunriseTime)) {
				  //data.sunriseTime = parseInt(weatherJson.sunriseTime);
				  const time = new Date(weatherJson.sunriseTime);
				  let hour = time.getHours().toString().padStart(2, "0");
				  let min = time.getMinutes().toString().padStart(2, "0");
				  data.sunriseTime = hour + ':' + min;
				}

				if (isFinite(weatherJson.sunsetTime)) {
				  //data.sunsetTime = parseInt(weatherJson.sunsetTime);
				  const time = new Date(weatherJson.sunsetTime);
				  let hour = time.getHours().toString().padStart(2, "0");
				  let min = time.getMinutes().toString().padStart(2, "0");
				  data.sunsetTime = hour + ':' + min;
				}

				if (isFinite(weatherJson.sunriseTime) && isFinite(weatherJson.sunsetTime)) {
					const diff = weatherJson.sunsetTime - weatherJson.sunriseTime;
					let hour = parseInt(diff / (1000 * 60 * 60)).toString().padStart(2, "0");
					let min = parseInt((diff % (1000 * 60 * 60)) / (1000 * 60)).toString().padStart(2, "0");
					data.dayDuration = hour + ':' + min;
				}

				if (isFinite(weatherJson.weatherTime)) {
				  const weatherTime = new Date(weatherJson.weatherTime);
				  let hour = weatherTime.getHours().toString().padStart(2, "0");
				  let min = weatherTime.getMinutes().toString().padStart(2, "0");
				  data.weatherTime = weatherTime.getDate() + ' ' + getMonthName(weatherTime.getMonth()) + ' ' + weatherTime.getFullYear() + '  ' + hour + ':' + min;
				}
			}
			return data
		}


		function getForecastData(fileName) {
		  console.log(`getForecastData()`);

			let weather_str = read_weather_file(fileName);
			console.log(`forecastJson = ${weather_str}`);
			let forecastJson = JSON.parse(weather_str);
			
			lastModTime.forecast = getFileModTime(fileName);

			let data = {
				cityName: null,
				weatherTime: null,
				forecast: []
			}
	  
			if (forecastJson != undefined && forecastJson != null) {
				if (forecastJson.cityName != undefined && forecastJson.cityName != null && forecastJson.cityName.length) {
				  data.cityName = forecastJson.cityName;
				  data.cityName = data.cityName.replace(data.cityName[0], data.cityName[0].toUpperCase());
				}

				if (isFinite(forecastJson.weatherTime)) {
				  data.weatherTime = parseInt(forecastJson.weatherTime);
				}

				for(let i = 0; i < daysNum; i++) {
					let dayForecast = {
							weatherIcon: 0,
							temperatureMax: '--',
							temperatureMin: '--',
							humidity: '--',
							pressure: '--',
							windSpeed: '--',
							windDirection: 0,
						}

					if (forecastJson != undefined && forecastJson != null) {
						if (isFinite(forecastJson.forecast[i].weatherIcon)) {
						  dayForecast.weatherIcon = parseInt(forecastJson.forecast[i].weatherIcon);
						}

						if (isFinite(forecastJson.forecast[i].temperatureMax)) {
						  dayForecast.temperatureMax = tempWithSign(forecastJson.forecast[i].temperatureMax);
						}

						if (isFinite(forecastJson.forecast[i].temperatureMin)) {
						  dayForecast.temperatureMin = tempWithSign(forecastJson.forecast[i].temperatureMin);
						}
						
						if (isFinite(forecastJson.forecast[i].humidity)) {
						  dayForecast.humidity = parseInt(forecastJson.forecast[i].humidity);
						}
						
						if (isFinite(forecastJson.forecast[i].pressure)) {
						  dayForecast.pressure = parseInt(forecastJson.forecast[i].pressure);
						}
						
						if (isFinite(forecastJson.forecast[i].windSpeed)) {
						  dayForecast.windSpeed = Math.round(parseFloat(forecastJson.forecast[i].windSpeed));
						}

						if (isFinite(forecastJson.forecast[i].windDirection)) {
						  dayForecast.windDirection = parseFloat(forecastJson.forecast[i].windDirection);
						}
					}
					
					data.forecast.push(dayForecast);

				}

			}
			return data
		}



//-----------------------------------------------------

		function strokeBtn(props) {			// кнопка с обводкой 
		
			let rectProps = {
			  x: props.x,
			  y: props.y,
			  w: props.w,
			  h: props.h,
			  radius: props.radius,
			  line_width: props.line_width || 2,
			  color: props.strokeColor,
			}

			let btnProps = {
			  x: props.x + 2,
			  y: props.y + 2,
			  w: props.w - 4,
			  h: props.h - 4,	
			  text: props.text || '',
			  text_size: props.text_size || 26,
			  color: props.textColor || 0xffffff,
			  radius: props.radius - 2,
			  normal_color: props.normal_color || 0x222222,
			  press_color: props.press_color || 0x454545,
			  click_func: props.click_func
			}

			let gr = props.group || hmUI;
			gr.createWidget(hmUI.widget.STROKE_RECT, rectProps);
			gr.createWidget(hmUI.widget.BUTTON, btnProps);
        }



		let weatherPanel = null, shadowScreen = null
		let weatherPanelVisible = false
		let lastTimeScreenOn = null
		
		function createScreenShadow() {

			shadowScreen = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: DEVICE_WIDTH,
              h: DEVICE_HEIGHT,
            });

			// затемнее экрана
            shadowScreen.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: DEVICE_WIDTH,
              h: DEVICE_HEIGHT,
			  radius: DEVICE_WIDTH / 2,
              color: 0x000000,
			  alpha: 100,
            });
			
			strokeBtn({
			  x: (DEVICE_WIDTH - 60) / 2,
			  y: DEVICE_HEIGHT - 62,
			  w: 60,
			  h: 60,
			  text: 'X',
			  text_size: 26,
			  radius: 17,
			  strokeColor: 0xff0000,
			  click_func: () => {
				vibro();
				deleteWeatherPanel();
			  },
			 group: shadowScreen
			});
		}


		function deleteWeatherPanel() {
			if (weatherPanel) hmUI.deleteWidget(weatherPanel);
			weatherPanel = null;
			if (shadowScreen) hmUI.deleteWidget(shadowScreen);
			shadowScreen = null;
			weatherPanelVisible = false;
		}

		function checkWeatherPanel() {
			if (!weatherPanelVisible) return
			
			const now = Date.now();
			const dTime = 10 * 1000 * 2;
			
			if (now - lastTimeScreenOn > dTime) deleteWeatherPanel()
			else lastTimeScreenOn = now;
		}



// информационная метео панель
		function createWeatherPanel() {

			const pD = sc(63);					// смещение панели от края экрана
			const pW = DEVICE_WIDTH - 2 * pD;	// ширина и 	
			const pH = DEVICE_HEIGHT - 2 * pD;	// высота панели

			const stings = [
								['Обн. ', 'Upd. '], 							// 0
								['Ощущается ', 'Feels like '], 					// 1
								['световой день', 'day duration'], 				// 2
							];


			weatherPanel = hmUI.createWidget(hmUI.widget.GROUP, {
              x: pD,
              y: pD,
              w: pW,
              h: pH,
            });

			// фон панели
            weatherPanel.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: pW,
              h: pH,
			  radius: 25,
              color: 0x000000,
			  alpha: 210,
            });

            weatherPanel.createWidget(hmUI.widget.STROKE_RECT, {
              x: 0,
              y: 0,
              w: pW,
              h: pH,
			  radius: 25,
			  color: 0xcccccc,
			  line_width: 1,
            });

			// время обновления
            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(15),
              y: sc(5),
              w: pW,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
			  text: stings[0][lang] + weatherData.weatherTime,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xb6b6b6,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

			// город
            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(150),
              y: sc(30),
              w: pW,
              h: 32,
              text_size: 28,
              char_space: 0,
              line_space: 0,
			  text: weatherData.cityName,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xe0e0e0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });
			
			weatherPanel.createWidget(hmUI.widget.IMG, {
              x: sc(28),
              y: sc(38),
			  w: 100,
			  h: 100,
			  auto_scale: true,
			  //alpha: 120,
              src: `w_${weatherData.weatherIcon}${nightIcons.includes(weatherData.weatherIcon) ? (isDayNow() ? '' : 'n') : ('')}.png`,
            });
			
            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(160),
              y: sc(60),
              w: 120,
              h: 50,
              text_size: 44,
              char_space: 0,
              line_space: 0,
			  text: weatherData.temperature,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

			// макс
            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(260),
              y: sc(65),
              w: 80,
              h: 24,
              text_size: 18,
              char_space: 0,
              line_space: 0,
			  //text: weatherData.temperatureMax,
			  text: forecastData.forecast[0].temperatureMax,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xdedede,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

			// мин
            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(260),
              y: sc(88),
              w: 80,
              h: 24,
              text_size: 18,
              char_space: 0,
              line_space: 0,
			  //text: weatherData.temperatureMin,
			  text: forecastData.forecast[0].temperatureMin,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xdedede,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

			// ощущается
            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(160),
              y: sc(110),
              w: 150,
              h: 24,
              text_size: 18,
              char_space: 0,
              line_space: 0,
			  text: stings[1][lang] + weatherData.temperatureFeels,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xdedede,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

			// описание погоды
            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: 5,
              y: sc(130),
              w: pW - 10,
              h: 32,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: weatherData.weatherDescription,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xe0e0e0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });
			

	// разделитель
            weatherPanel.createWidget(hmUI.widget.FILL_RECT, {
              x: 30,
              y: sc(170),
              w: pW - 60,
              h: 1,
			  color: 0xcccccc,
			  alpha: 180,
            });
			
	// восход
			weatherPanel.createWidget(hmUI.widget.IMG, {
              x: sc(13),
              y: sc(180),
              w: 30,
              h: 26,
			  src: 'ic_param_sunrise.png',
			});

            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(46),
              y: sc(178),
              w: 110,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: weatherData.sunriseTime,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });
			
	// закат
			weatherPanel.createWidget(hmUI.widget.IMG, {
              x: sc(240),
              y: sc(180),
              w: 30,
              h: 26,
			  src: 'ic_param_sunset.png',
			});

            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(271),
              y: sc(178),
              w: 110,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: weatherData.sunsetTime,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });
			
	// световой день
            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: sc(178),
              w: pW,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: weatherData.dayDuration,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xdedede,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

            weatherPanel.createWidget(hmUI.widget.FILL_RECT, {
              x: sc(108),
              y: sc(193),
              w: sc(30),
              h: 1,
			  color: 0xcccccc,
			  alpha: 180,
            });

            weatherPanel.createWidget(hmUI.widget.FILL_RECT, {
              x: sc(204),
              y: sc(193),
              w: sc(30),
              h: 1,
			  color: 0xcccccc,
			  alpha: 180,
            });

            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: sc(198),
              w: pW,
              h: 30,
              text_size: 18,
              char_space: 0,
              line_space: 0,
			  text: stings[2][lang],
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0x999999,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

	// ветер
			weatherPanel.createWidget(hmUI.widget.IMG, {
              x: sc(28),
              y: sc(231),
              w: 30,
              h: 26,
			  src: 'ic_param_wind.png',
			});

			let windStr = weatherData.windSpeed;
			if (weatherData.windGusts) windStr += ` (${weatherData.windGusts})`
			windStr += speedUnit[0][lang];
			
            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(65),
              y: sc(224),
              w: 150,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: windStr,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });
			
			weatherPanel.createWidget(hmUI.widget.IMG, {
              x: sc(206 - 17/2),
              y: sc(234 - 21/2),
              w: 34,
              h: 42,
			  pos_x: 17/2,
			  pos_y: 21/2,
			  center_x: 17,
			  center_y: 21,
			  angle: weatherData.windDirection,
			  src: 'ico_wind.png',
			});
			
            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(242),
              y: sc(224),
              w: 110,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: getWindDescription(weatherData.windDirection),
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });


	// давление
			weatherPanel.createWidget(hmUI.widget.IMG, {
              x: sc(28),
              y: sc(268),
              w: 30,
              h: 26,
			  src: 'ic_param_pressure.png',
			});

            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(65),
              y: sc(261),
              w: 120,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: getPressure(weatherData.pressure) + pressUnit[0][lang],
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

	// влажность
			weatherPanel.createWidget(hmUI.widget.IMG, {
              x: sc(28),
              y: sc(305),
              w: 30,
              h: 26,
			  src: 'ic_param_humidity.png',
			});

            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(65),
              y: sc(298),
              w: 110,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: weatherData.humidity,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

	// видимость
			weatherPanel.createWidget(hmUI.widget.IMG, {
              x: sc(201),
              y: sc(268),
              w: 30,
              h: 26,
			  src: 'ic_param_visibility.png',
			});

            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(238),
              y: sc(261),
              w: 110,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: weatherData.visibility,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

	// осадки
			weatherPanel.createWidget(hmUI.widget.IMG, {
              x: sc(201),
              y: sc(305),
              w: 30,
              h: 26,
			  src: 'ic_param_precipitation.png',
			});

            weatherPanel.createWidget(hmUI.widget.TEXT, {
              x: sc(238),
              y: sc(298),
              w: 110,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: weatherData.chanceOfRain,
			  font: 'fonts/DIN_Pro_Regular.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

			lastTimeScreenOn = Date.now();
			weatherPanelVisible = true;

		}




//--------------------------------------------------------------------------------------------

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            normalWF() {
                
            console.log('Watch_Face.ScreenNormal  Meteo');

	//------------ кэши шрифтов
			// время
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 120,
			  h: 105,
              text_size: 100,
              char_space: 0,
              line_space: 0,
              font: 'fonts/eras-demi-itc.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 /_-.,:;`'%°",
            });

			// время АОД
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 180,
			  h: 150,
              text_size: 140,
              char_space: 0,
              line_space: 0,
              font: 'fonts/eras-demi-itc.ttf',
              color: 0xffffff,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 /_-.,:;`'%°",
            });

			// название города
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 40,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ kminaxg кминасрт АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ/_-.,:;`'%°",
            });

			// температура текущая
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 50,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 /_-.,:;`'%°",
            });
			
			// влажность, скорость ветра
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ kminaxg кминасрт АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ/_-.,:;`'%°",
            });

			// время обновления 
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 30,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ kminaxg кминасрт АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ/_-.,:;`'%°",
            });
			
			// дни недели
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 35,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz  АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя/_-.,:;`'%°",
            });
			
			// дата
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 50,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 /_-.,:;`'%°",
            });
			
			// активность
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 44,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ kminaxg кминасрт АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ/_-.,:;`'%°",
            });

			// заряд батареи
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 34,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 /_-.,:;`'%°",
            });
	//-- кэши шрифтов ---------------------------------

			hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
			  w: DEVICE_WIDTH,
			  h: DEVICE_HEIGHT,
			  auto_scale: true,
              src: 'bg.png',
            });

			copyright = hmUI.createWidget(hmUI.widget.TEXT, {
				x: DEVICE_WIDTH - 70,
				y: sc(40),
				w: 70,
				h: 30,
				text_size: 24,
				text: 'leXxiR',
				color: 0xffffff,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
			});

			hmUI.createWidget(hmUI.widget.TEXT, {
				x: DEVICE_WIDTH - 59,
				y: sc(64),
				w: 70,
				h: 30,
				text_size: 24,
				text: '4pda',
				color: 0x4bd9da,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
			});

	//----- время -----
			hourText = new TextWithOutline({
			  x: sc(60),
			  y: sc(58),
			  w: 120,
			  h: 105,
			  text_size: 100,
			  char_space: 0,
			  line_space: 0,
			  color: 0xffffff,
			  offset: 1,
			  text: '00',
			  font: 'fonts/eras-demi-itc.ttf',
			  align_h: hmUI.align.LEFT,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
			});

			minText = new TextWithOutline({
			  x:  sc(60),
			  y:  sc(140),
			  w: 120,
			  h: 105,
			  text_size: 100,
			  char_space: 0,
			  line_space: 0,
			  color: 0xc0c0c0,
			  offset: 1,
			  text: '00',
			  font: 'fonts/eras-demi-itc.ttf',
			  align_h: hmUI.align.LEFT,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
			});


	//----- погода -----
			curWeatherIcon = hmUI.createWidget(hmUI.widget.IMG, {
              x: sc(207),
              y: sc(107),
			  w: sc(100),
			  h: sc(100),
			  auto_scale: true,
              src: 'w_0.png',
            });

            curCityName = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(207),
              y: sc(80),
              w: 200,
              h: 40,
              text_size: 28,
              char_space: 0,
              line_space: 0,
			  //text: 'Пятигорск',
			  text: '--',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });
			
            curTempText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(320),
              y: sc(110),
              w: 90,
              h: 50,
              text_size: 44,
              char_space: 0,
              line_space: 0,
			  //text: '26°',
			  text: '--',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

			hmUI.createWidget(hmUI.widget.IMG, {
              x: sc(323),
              y: sc(162),
              w: 17,
              h: 21,
			  src: 'ico_hum.png',
			});

            curHumText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(350),
              y: sc(152),
              w: 80,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  //text: '40%',
			  text: '--',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

			curWindPointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: sc(323-17/2),
              y: sc(187-21/2),
              w: 34,
              h: 42,
			  pos_x: 17/2,
			  pos_y: 21/2,
			  center_x: 17,
			  center_y: 21,
			  angle: 0,
			  src: 'ico_wind.png',
			});

            curWindText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(350),
              y: sc(177),
              w: 110,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  //text: '3,2 м/с',
			  text: '',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

            updateTimeText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(207),
              y: sc(205),
              w: 220,
              h: 30,
              text_size: 18,
              char_space: 0,
              line_space: 0,
			  //text: '20 октября 2024  21:39',
			  text: '--/--',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xb6b6b6,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

	//----- дни -----
			for(let i = 0; i < daysNum; i++) {
				dayNameText[i] = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: sc(25) + sc(84) * i,
				  y: centerY + 10,
				  w: 80,
				  h: 35,
				  text_size: 26,
				  char_space: 1,
				  line_space: 0,
				  text: '',
				  font: 'fonts/DirectoBold.ttf',
				  color: 0xffffff,
				  //color: 0xfff996,
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				});
				
				// дневная и ночная температуры
				let highTemp = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: sc(22) + sc(84) * i,
				  y: sc(326),
				  w: 80,
				  h: 35,
				  text_size: 24,
				  char_space: 1,
				  line_space: 0,
				  text: '',
				  //text: `${24 - i*4}°`,
				  font: 'fonts/DirectoBold.ttf',
				  color: 0xf0f0f0,
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				});
				
				let lowTemp = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: sc(22) + sc(84) * i,
				  y: sc(349),
				  w: 80,
				  h: 35,
				  text_size: 24,
				  char_space: 1,
				  line_space: 0,
				  text: '',
				  //text: `${12 - i*5}°`,
				  font: 'fonts/DirectoBold.ttf',
				  color: 0xb1b1b1,
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				});
				
				dayTemp.push({ high: highTemp, low: lowTemp });
				
				if(i)
				dayWeatherIcon[i] = hmUI.createWidget(hmUI.widget.IMG, {
				  x: sc(38) + sc(84) * i,
				  y: sc(270),
				  w: sc(55),
				  h: sc(55),
				  auto_scale: true,
				  src: 'w_0.png',
				  //src: `w_${i}.png`,
				});
			}
	
	//----- дата -----
            dateText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(25),
              y: centerY + 42,
              w: 80,
              h: 50,
              text_size: 46,
              char_space: 0,
              line_space: 0,
			  text: '40',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
            });


	//----- Активность -----
			actIcon = hmUI.createWidget(hmUI.widget.IMG, {
              x: centerX - 80,
              y: DEVICE_HEIGHT - 76,
              w: 46,
              h: 46,
			  auto_scale: true,
			  src: `ico_${actIndex}.png`,
			});

            actValueText = new TextWithShadow({
              x: centerX - 55,
              y: DEVICE_HEIGHT - 78,
              w: 150,
              h: 44,
              text_size: 36,
              char_space: 0,
              line_space: 0,
			  text: getActivityValue(actIndex),
			  font: 'fonts/DirectoBold.ttf',
              color: 0xe5e5e5,
			  color_shadow: 0x404040,
			  offset: 2,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
            });

            hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: sc(160),
			  y: DEVICE_HEIGHT - 30,
			  w: DEVICE_WIDTH - 2 * sc(160),
			  h: 10,
              color: 0x000000,
			  alpha: 100,
			  radius: 3,
            });

            actScale = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: sc(160),
			  y: DEVICE_HEIGHT - 30,
			  w: 0,
			  h: 10,
              color: 0xdedede,
			  radius: 3,
            });



	//----- батарея -----

			hmUI.createWidget(hmUI.widget.IMG, {
              x: centerX - 47,
              y: sc(32),
              w: 26,
              h: 36,
			  src: 'ico_batt.png',
			});

            battText = new TextWithShadow({
              x: centerX - 19,
              y: sc(30),
              w: 110,
              h: 34,
              text_size: 30,
              char_space: 0,
              line_space: 0,
			  text: '84%',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xf0f0f0,
			  color_shadow: 0x404040,
			  offset: 1,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
            });

            hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: sc(190),
			  y: sc(17),
			  w: DEVICE_WIDTH - 2 * sc(190),
			  h: 10,
              color: 0x000000,
			  alpha: 100,
			  radius: 3,
            });

            battScale = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: sc(190),
			  y: sc(17),
			  w: 0,
			  h: 10,
              color: 0xdedede,
			  radius: 3,
            });

			hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              //x: centerX - 44,
			  x: sc(25),
              //y: sc(31),
			  y: sc(130),
			  src: 'status_bt.png',
			  type: hmUI.system_status.DISCONNECT,
			});

	// будильник
		// фоновый значок
			hmUI.createWidget(hmUI.widget.IMG, {
			  x: sc(17),
			  y: sc(178),
              w: 36,
              h: 34,
			  src: 'alarm_off.png',
			});

			hmUI.createWidget(hmUI.widget.IMG_STATUS, {
			  x: sc(17),
			  y: sc(178),
			  src: 'status_clock.png',
			  type: hmUI.system_status.CLOCK,
			});
			
// БУДИЛЬНИК для превью
/*
            hmUI.createWidget(hmUI.widget.TEXT, {
				x: sc(3),
				y: sc(207),
				w: 60,
				h: 26,
				text_size: 20,
				color: 0xf0f0f0,
				font: 'fonts/DirectoBold.ttf',
				text: '07:20',
				padding: true,
				align_h: hmUI.align.CENTER_H,
				type: hmUI.data_type.ALARM_CLOCK,
            });
*/
            hmUI.createWidget(hmUI.widget.TEXT_FONT, {
				x: sc(3),
				y: sc(207),
				w: 60,
				h: 46,
				text_size: 20,
				color: 0xf0f0f0,
				font: 'fonts/DirectoBold.ttf',
				padding: true,
				invalid_visible: false,
				align_h: hmUI.align.CENTER_H,
				type: hmUI.data_type.ALARM_CLOCK,
            });


//----- тап-зоны -----
		// будильник
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
				x: sc(3),
				y: sc(170),
				w: 60,
				h: 60,
				src: 'blank.png',
				type: hmUI.data_type.ALARM_CLOCK,
            });

		// календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: sc(30),
              y: sc(242),
			  w: sc(70),
			  h: sc(80),
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				vibro();
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			});

		// метеопанель
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: sc(200),
              y: sc(85),
			  w: sc(190),
			  h: sc(140),
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				vibro();
				createScreenShadow();
				createWeatherPanel();
			  },
			});
		
		// погода приложение
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: sc(390),
              y: sc(85),
			  w: sc(60),
			  h: sc(140),
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				vibro();
				//launchApp({ url: 'WeatherScreen', native: true });
				setTimeout(() => {
					//launchApp({ appId: mini_app_id, url: 'page/index' });
					hmApp.startApp({ appid: mini_app_id, url: 'page/index' });
				}, 100);
			  },
			});

		// переключаем активности - нажатие
		// запуск приложения активности - долгое нажатие
/*
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: centerX - 80,
              y: DEVICE_HEIGHT - 80,
			  w: 160,
			  h: 80,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				toggleActivity();
			  },
			  longpress_func: () => {
				  showActivityScreen();
			  },
			});
*/

			activity_btn = hmUI.createWidget(hmUI.widget.IMG, {
              x: centerX - 80,
              y: DEVICE_HEIGHT - 80,
			  w: sc(160),
			  h: sc(80),
			  src: 'blank.png',
			});
			
			activity_btn.addEventListener(hmUI.event.CLICK_DOWN, function () {
				if(longPress_Timer) clearTimeout(longPress_Timer);
				longPress_Timer = setTimeout(() => {
					showActivityScreen();
				}, longPressDelay);

			});
			activity_btn.addEventListener(hmUI.event.CLICK_UP, function () {
				if(longPress_Timer) clearTimeout(longPress_Timer);
				toggleActivity();
			});




			curTime.addEventListener(curTime.event.MINUTEEND, function () {
				updateAllInfo();
			});

			step.addEventListener(hmSensor.event.CHANGE, function() {
				if (actIndex == 0) updateActivity(0);
			});

            battery.addEventListener(hmSensor.event.CHANGE, function() {
				updateBattery();
            });

            heart.addEventListener(hmSensor.event.LAST, function() {
				if (actIndex == 2) updateActivity(2);
            });

			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: (function () {
				getLangIndex();
				updateAllInfo();
				checkWeatherPanel();
				onDigitalCrown();
				updateWeatherData();
				toggleWeatherIcons();
			  }),
			  pause_call: (function () {
				if(longPress_Timer) clearTimeout(longPress_Timer);
				offDigitalCrown();
				//if (weatherPanelVisible) lastTimeScreenOn = Date.now(); - не работает с АОД
			  }),
			})


            },
            makeAOD() {
	
				hourText = new TextWithOutline({
				  x: DEVICE_WIDTH/2 - 10 - 180,
				  y: (DEVICE_HEIGHT - 150 ) /2,
				  w: 180,
				  h: 150,
				  text_size: 140,
				  char_space: 0,
				  line_space: 0,
				  color: 0xffffff,
				  offset: 1,
				  text: '00',
				  font: 'fonts/eras-demi-itc.ttf',
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				});

				minText = new TextWithOutline({
				  x: DEVICE_WIDTH/2 + 10,
				  y: (DEVICE_HEIGHT - 150 ) /2,
				  w: 180,
				  h: 150,
				  text_size: 140,
				  char_space: 0,
				  line_space: 0,
				  color: 0xc0c0c0,
				  offset: 1,
				  text: '00',
				  font: 'fonts/eras-demi-itc.ttf',
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				});

				updateTimeAOD();
				
				curTime.addEventListener(curTime.event.MINUTEEND, function () {
					updateTimeAOD();
				});

            },
            onInit() {
            },
            build() {
                if (isAOD) this.makeAOD()
				else this.normalWF();
            },
            onDestroy() {
				offDigitalCrown();
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}